import { marked } from 'marked';
import htmlDocx from 'html-docx-js/dist/html-docx';

import React, {Component} from "react";
import {observer, inject} from "mobx-react";
import {message} from "antd";

import {download, dateFormat} from "../../../utils/helper";
import {EXPORT_FILENAME_SUFFIX} from "../../../utils/constant";
import "../common.css";

@inject("content")
@observer
class ExportWord extends Component {
  handleClick = () => {
    const {markdownEditor} = this.props.content;
    const content = markdownEditor.getValue();
    if ("download" in document.createElement("a")) {
      //download(content, dateFormat(new Date(), "yyyy-MM-dd") + ".docx");
    // Step 1: Markdown to HTML
    const html = marked.parse(content);

    // Step 2: Add basic HTML structure
    const fullHtml = `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${html}</body></html>`;

    // Step 3: HTML to docx
    const converted = htmlDocx.asBlob(fullHtml);

    // Step 4: Trigger download
    const link = document.createElement('a');
    link.href = URL.createObjectURL(converted);
    link.download = dateFormat(new Date(), "yyyy-MM-dd") +'.docx';
    link.click();
    } else {
      message.warn("浏览器不支持");
    }
};

  render() {
    return (
      <div id="nice-menu-export-word" className="nice-menu-item" onClick={this.handleClick}>
        <span>
          <span className="nice-menu-flag" />
          <span className="nice-menu-name">导出 word</span>
        </span>
      </div>
    );
  }
}

export default ExportWord;
