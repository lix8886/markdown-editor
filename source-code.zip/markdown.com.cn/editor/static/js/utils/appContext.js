import React from "react";

const appContext = React.createContext(null);

export default appContext;
