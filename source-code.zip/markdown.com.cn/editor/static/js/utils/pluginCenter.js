// 检测插件是否安装
export default {
  mathjax: false,
};
